﻿using Microsoft.EntityFrameworkCore;
using PermissionRequest.Domain.Models;

namespace PermissionRequest.Infraestructure.Context
{
    public class SqlContext : DbContext
    {
        public SqlContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {         

            modelBuilder.Entity<PermissionsModel>()
                .HasOne(t => t.TipoPermisoModels)
                .WithMany(q => q.PermisoModel)
                .HasForeignKey(x => x.TipoPermiso)
                .HasPrincipalKey(p=> p.Id);
        }

        public DbSet<PermissionsModel> PermisoModels { get; set; }
        public DbSet<PermissionsTypeModel> TipoPermisoModels { get; set; }
    }
}
