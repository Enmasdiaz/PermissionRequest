﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PermissionRequest.Domain.Models
{
    [Table("Permiso")]
    public class PermissionsModel
    {
        [Column("Id")]
        [Key]
        public int? Id { get; }
        [Column("NombreEmpleado")]
        public string NombreEmpleado { get; set; }
        [Column("ApellidoEmpleado")]
        public string ApellidoEmpleado { get; set; }
        [Column("TipoPermiso")]
        public int? TipoPermiso { get; set; }
        [Column("FechaPermiso")]
        public DateTime FechaPermiso { get; set; }

        public PermissionsTypeModel TipoPermisoModels { get; set; }

    }
}
