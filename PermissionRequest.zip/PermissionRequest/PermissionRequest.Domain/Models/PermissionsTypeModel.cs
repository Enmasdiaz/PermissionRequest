﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PermissionRequest.Domain.Models
{
    [Table("TipoPermiso")]
    public class PermissionsTypeModel
    {
        [Column("Id")]
        [Key]
        public int? Id { get; }
        [Column("Descripcion")]
        public string Descripcion { get; set; }

        public List<PermissionsModel> PermisoModel { get; set; }
    }
}
